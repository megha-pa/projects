import kfp
import json
import time
from google.cloud import bigquery
from google.cloud.exceptions import NotFound
from kfp.v2.google.client import AIPlatformClient
from google.cloud.aiplatform import pipeline_jobs
 
def create_pipeline_run(self):
    
    print('Kicking off a pipeline run...')
    PROJECT_ID = "pod-devops"
    query_string = f"""SELECT Order_Date,Product_ID,Sales FROM `{PROJECT_ID}.mlops_data.data_final`
    where Product_ID IN("OFF-AR-10001166","OFF-PA-10004022","OFF-BI-10001525","FUR-CH-10000988","TEC-PH-10003885") """
    from datetime import datetime
    TIMESTAMP = datetime.now().strftime("%Y%m%d%H%M%S")
    run1 = pipeline_jobs.PipelineJob(
        display_name="welspun_pipeline",
        template_path="gs://welspun_mlops_data1/azdemo-pipeline.json",
        job_id="welspun-pipeline-{0}".format(TIMESTAMP),
        parameter_values={
                            "req_query": query_string,
                            "PROJECT_ID": PROJECT_ID,
        },
        
        enable_caching=False,
    )
    run1.run()
    return "job submitted"

 